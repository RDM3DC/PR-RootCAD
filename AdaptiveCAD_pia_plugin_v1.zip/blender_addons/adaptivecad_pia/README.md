# Blender Add-on: AdaptiveCAD πₐ Toolpath
Install via `Edit → Preferences → Add-ons → Install...` and select this folder as a zip.
Add from `Add → Curve → πₐ Toolpath`. Adjust radius/steps/λ in the operator popup.
