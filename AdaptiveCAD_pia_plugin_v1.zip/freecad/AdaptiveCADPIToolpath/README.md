# FreeCAD Macro: AdaptiveCAD πₐ Toolpath
Use `Macro → Macros… → Execute` and select `pia_toolpath.py`. It will add two wires:
- `piA_Path` (πₐ adaptive)
- `Euclid_Circle` (reference)
Adjust defaults by editing `run(radius, steps, lam)` at the bottom.
