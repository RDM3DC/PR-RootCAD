# PR1 + PR2 Drop-In (AdaptiveCAD)

This zip contains:
- **PR1:** `adaptivecad/pi/kernel.py` + `tests/test_pi_kernel.py`
- **PR2:** `plugins/freecad_pia/` (Workbench with Adaptive Circle + Settings)

## Apply to your repo
1. Unzip into the root of your **AdaptiveCAD** checkout (it will create `adaptivecad/pi/`, `tests/`, and `plugins/freecad_pia/` if they don't exist).
2. Commit as two separate commits (PR1 then PR2) or open two PRs.

## Dev quickstart
```bash
# From repo root
pytest -q  # runs tests/test_pi_kernel.py
```

## FreeCAD install
- Copy `plugins/freecad_pia` into your FreeCAD Mod folder:
  - Linux/macOS: `~/.FreeCAD/Mod/freecad_pia`
  - Windows: `%APPDATA%\FreeCAD\Mod\freecad_pia`
- Ensure your AdaptiveCAD repo path is on `sys.path` (symlink the repo into `~/.FreeCAD/Mod/AdaptiveCAD` or add a custom path loader).
- Start FreeCAD → select **PiA** workbench → use **Adaptive Circle**.

