# PR3 + PR4 Drop-In (AdaptiveCAD)

This bundle contains:
- **PR3:** `plugins/blender_pia/` — Blender add-on with Adaptive-π Circle + Heatmap
- **PR4:** `adaptivecad/cam/pia_compensation.py` + `tools/pia_compensate_gcode.py` — CAM compensation (G-code), tests, and docs

**Note on CI failure you saw:** `pytest` failed due to `quantum_visualization.py` missing `Any`. 
Add this one-liner at the top of that file:
```python
from typing import Any
```
—or apply the included patch: `git apply patches/quantum_visualization_any.patch`.

## Quick Apply
Unzip into your AdaptiveCAD repo root (it will create `plugins/blender_pia/`, `adaptivecad/cam/`, `tools/`, `tests/`, `patches/`). Commit as two PRs:
- **PR3:** Blender add-on
- **PR4:** CAM compensation + tests

## Blender Add-on (PR3)
Install from `Edit > Preferences > Add-ons > Install...` and select the zip of `plugins/blender_pia` folder, or copy `plugins/blender_pia` into your scripts add-ons dir.

Tools:
- **Add Adaptive-π Circle:** mesh circle whose circumference is scaled by πₐ (β, s₀, clamp in prefs).
- **PiA Heatmap:** writes a `pia` vertex color layer using a simple curvature proxy and maps it to colors.

## CAM Compensation (PR4)
Compensates **G2/G3 arcs** in G-code using πₐ with κ≈1/r and scale≈r (hole/arc assumption). 
CLI:
```bash
python tools/pia_compensate_gcode.py input.gcode -o out.gcode --beta 0.2 --s0 1.0 --clamp 0.3 --min_arc_mm 0.5 --max_arc_mm 100.0
```

## Tests
Run:
```bash
pytest -q tests/test_pia_cam_comp.py
```
